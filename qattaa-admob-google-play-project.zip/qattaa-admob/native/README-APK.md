# إعداد APK مع AdMob

هذه النسخة تستخدم Capacitor لأن PWABuilder/TWA لا يستطيع تشغيل AdMob الأصلي.

## قبل البناء

1. ثبّت Node.js وAndroid Studio وAndroid SDK.
2. من مجلد المشروع نفّذ:

```bash
npm install
npx cap add android
```

3. افتح `android/app/src/main/AndroidManifest.xml` وأضف هذا داخل وسم
   `<application>`:

```xml
<meta-data
    android:name="com.google.android.gms.ads.APPLICATION_ID"
    android:value="ca-app-pub-3940256099942544~3347511713" />
```

المعرّف السابق تجريبي من Google. لا تنشر به.

4. ثبّت الإضافة وزامن المشروع:

```bash
npm install @capacitor-community/admob
npx cap sync android
```

5. ابنِ APK تجريبيًا من Android Studio، أو:

```bash
cd android
./gradlew assembleDebug
```

## مواضع الإعلانات

- **إعلان مكافأة — فرصة إضافية:** يظهر بعد انتهاء الجولة، ويعيد اللعب
  لمدة 20 ثانية بعد اكتمال المشاهدة.
- **إعلان مكافأة — مضاعفة الخبرة:** يظهر من شاشة النتيجة، ويضاعف خبرة
  الجولة بعد اكتمال المشاهدة.
- **إعلان بيني:** يظهر بعد كل 3 جولات فقط، وبعد تأخير قصير من شاشة النتيجة.

لا يوجد بانر أثناء اللعب؛ لأنه يغطي مساحة السحب والقطع ويؤذي تجربة اللعبة.

## قبل النشر

- أنشئ App ID ووحدتي Rewarded وInterstitial في حساب AdMob.
- ضع App ID في `AndroidManifest.xml`.
- ضع معرّفي الوحدتين في نهاية `www/index.html` داخل `AD_IDS`.
- غيّر `ADS_TEST_MODE` إلى `false` فقط بعد التأكد من أن معرّفاتك
  الحقيقية موجودة وأنك تختبر من خلال مسار النشر المناسب.
- لا تضغط على إعلاناتك ولا تستخدم معرّفات حقيقية أثناء التطوير.