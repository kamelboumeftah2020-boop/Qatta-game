import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.kamelbmh.qattaa',
  appName: 'قطع الكلمة',
  webDir: 'www',
  android: {
    backgroundColor: '#0B1224'
  }
};

export default config;